# coding:UTF-8

print('１〜３の数値を入力してください。',end='')
x = int(input())
while True:
    if x == 1:
        print('グー')

    elif x == 2:
        print('チョキ')

    elif x == 3:
        print('パー')

    print('１〜３の数値を入力してください。',end='')
    x = int(input())
