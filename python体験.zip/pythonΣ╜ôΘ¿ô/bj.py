import random 
from time import sleep

def rand(point):
    x =  random.randint(1,12)
    if x > 10:
        x =  10
    elif x == 1:
        if sum(point) <= 10:
            x = 11
        else:
            x = 1
    return x


print('ブラックジャックを始めます。')

while True:
    print('Y(遊ぶ),N(終わる)',end='')

    D = []
    while sum(D) < 16:
        D.append(rand(D))  
# ユーザ点数用意
    P = []
#flag管理
    game = 'Y'
    tuika = ''

    game = input()
    if game == 'N' or game == 'n':
        break
    

    P.append(rand(P))

    while True:
        print('ディーラーの手札',D[:2],'合計%i'%sum(D[:2]))
        print('あなたの手札',P,'合計%i'%sum(P))

        if sum(P) == 21:
            print('あなたの勝ちです。')
            break
        elif sum(D) == 21:
            print('あなたの負けです。')
            break
        elif sum(P) > 21:
            print('あなたの負けです。')
            break

        print('Y(引く),N(引かない)',end='')
        tuika = input()
        if tuika == 'Y' or tuika == 'y':
            P.append(rand(P))
        else:
    # ディーラー1枚ずつ引く
            for i in range(2,len(D)):
                print('ディーラー,一枚引きます',D[:i+1],'合計%i'%sum(D[:i+1]))
                sleep(2)
            if sum(D) == 21:
                print('あなたの負けです。')
            elif sum(D) > 21 :
                print('あなたの勝ちです。')
            elif sum(P) > sum(D):
                print('あなたの勝ちです。')
            elif sum(P) < sum(D):
                print('あなたの負けです。')

            break



    
